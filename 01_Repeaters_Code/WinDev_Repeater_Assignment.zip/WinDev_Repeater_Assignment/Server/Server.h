
extern "C" double GetConeVolume( float i_radius, float i_height);
